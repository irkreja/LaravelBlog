<?php $__env->startSection('content'); ?>
<div class="col-sm-8 blog-main">
   <h1>Edit a Post</h1>
   <hr>
   <form method="POST" action="/posts/<?php echo e($post->id); ?>">
	   <?php echo csrf_field(); ?>
	   <?php echo method_field('PUT'); ?>
	   <div class="form-group">
		   <label for="title">Title :</label>
	   <input type="text" class="form-control" id="title" name="title" value="<?php echo e($post->title); ?>">
	   </div>
	   <div class="form-group">
		   <label for="body">Body :</label>
		   <textarea name="body" class="form-control" id="" cols="30" rows="10"><?php echo e($post->body); ?></textarea>
	   </div>
	   <div class="form-group">
		   <label for="tags">Tags :</label>
		   <input type="text" class="form-control" id="tags" name="tags"  value="<?php echo e($post->tags->pluck('name')->implode(', ')); ?>">
	   </div>
	   <div class="form-group">
		   <button type="submit" class="btn btn-primary">Submit</button>
	   </div>
	   <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   </form>

</div>
<!-- /.blog-main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>