<div class="blog-post">
	<a href="/posts/<?php echo e($post->id); ?>">
		<h3 class="blog-post-title"><?php echo e($post->title); ?></h3>
	</a>
	<div class="blog-post-info d-flex">
		<p class="blog-post-meta"><?php echo e($post->created_at->toFormattedDateString()); ?> by
			<strong><?php echo e($post->user->name); ?></strong>
		</p>
		<div class="likes-count engagement-count ml-auto mr-2">
			<form action="/posts/<?php echo e($post->id); ?>/like" method="post">
				<?php echo csrf_field(); ?>
				<button type="submit" class="toggle-heart 	<?php echo e($post->likes()->where(['user_id'=> auth()->id()])->exists() ? 'liked' : ''); ?>">❤
					<span class="likes-count-number"><?php echo e($post->likes->count()); ?></span>
				</button>
			</form>
		</div>
		<div class="likes-count engagement-count mr-2">
				<form action="/posts/<?php echo e($post->id); ?>/edit" method="GET">
					<?php echo csrf_field(); ?>
					<button type="submit" class="btn btn-primary btn-sm">Edit Post</button>
				</form>
			</div>
		<div class="edit-post">
			<form action="/post/<?php echo e($post->id); ?>" method="POST">
				<?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
				<button type="submit" class="toggle-heart"></button>
			</form>
		</div>
		<?php if($post->user->id===auth()->id()): ?>
		<form action="">
			<button type="submit" class="btn btn-sm btn-warning mr-2">Edit post</button>
		</form>
		<form action="">
			<button type="submit" class="btn btn-sm btn-danger mr-4">Delete</button>
		</form>
		<?php endif; ?>
	</div>

	<p><?php echo e($post->body); ?></p>
</div>