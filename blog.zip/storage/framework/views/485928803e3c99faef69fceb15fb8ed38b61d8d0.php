<div class="blog-post">
	<a href="/posts/<?php echo e($post->id); ?>">
		<h3 class="blog-post-title"><?php echo e($post->title); ?></h3>
	</a>
	<div class="blog-post-info d-flex">
		<p class="blog-post-meta"><?php echo e($post->created_at->toFormattedDateString()); ?> by
			<strong><?php echo e($post->user->name); ?></strong>
		</p>
		<?php if(auth()->guard()->check()): ?>
		<div class="likes-count engagement-count ml-auto mr-2">
			<form action="/posts/<?php echo e($post->id); ?>/like" method="post">
				<?php echo csrf_field(); ?>
				<button type="submit" class="toggle-heart 	<?php echo e($post->likes()->where(['user_id'=> auth()->id()])->exists() ? 'liked' : ''); ?>">❤
					<span class="likes-count-number"><?php echo e($post->likes->count()); ?></span>
				</button>
			</form>
		</div>
		<?php else: ?>
		<div class="likes-count engagement-count ml-auto mr-2">
				<span class="toggle-heart">❤
					<span class="likes-count-number"><?php echo e($post->likes->count()); ?></span>
				</span>
		</div>
		<?php endif; ?>
		<?php if($post->user->id===auth()->id()): ?>
		<div class="editPost mr-2">
				<form action="/posts/<?php echo e($post->id); ?>/edit" method="GET">
					<?php echo csrf_field(); ?>
					<button type="submit" class="btn btn-primary btn-sm">Edit Post</button>
				</form>
			</div>
		<form action="/posts/<?php echo e($post->id); ?>" method="POST">
			<?php echo method_field('DELETE'); ?>
			<?php echo csrf_field(); ?>
			<button type="submit" class="btn btn-sm btn-danger mr-4">Delete</button>
		</form>
		<?php endif; ?>
	</div>

	<p><?php echo e($post->body); ?></p>
	<hr>
	<?php if($tags = $post->tags->pluck('name')->all()): ?>
	<div class="tags">
		<?php $__currentLoopData = $post->tags->pluck('name')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="/t/<?php echo e($tag); ?>">
		<span class="tag">#<?php echo e($tag); ?></span>
		</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<?php endif; ?>
</div>